import {StyleSheet, Text, View, Dimensions} from 'react-native';
import React, {Component} from 'react';

const deviceWidth = Dimensions.get('window').width;
const deviceHeight = Dimensions.get('window').height;
// console.log('deviceWidth==-', deviceWidth);
// console.log('deviceHeight==-', deviceHeight);
export default class PostMenu extends Component {
  render() {
    return (
      <View style={styles.postMenu}>
        <Text style={[styles.menuTxt, {color: 'red'}]}>Hide Ad</Text>
        <Text style={[styles.menuTxt, {color: 'red'}]}>Report Ad</Text>
        <Text style={styles.menuTxt}>Why you're seeing this ad</Text>
        <Text style={styles.menuTxt}>About this account</Text>
        <Text style={styles.menuTxt}>About Instagram ads</Text>
        {/* <Text style={styles.menuTxt}>PostMenu</Text> */}
      </View>
    );
  }
}

const styles = StyleSheet.create({
  postMenu: {
    backgroundColor: 'blue',
    position: 'absolute',
    zIndex: 10,
    width: deviceWidth - 100,
    // height: deviceHeight / 2,
    top: 0,
    right: 0,
    borderRadius: 10,
    paddingVertical: 20,
  },
  menuTxt: {
    fontSize: 16,
    fontWeight: '500',
    paddingHorizontal: 30,
    paddingVertical: 15,
  },
});
